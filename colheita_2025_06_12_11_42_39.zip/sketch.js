let colheitadeira;
let milhoItems = [];  // Itens de milho a serem coletados
let commerce;
let coletados = 0;  // Número de milhos coletados

function setup() {
  createCanvas(800, 400);
  
  // Criando a colheitadeira
  colheitadeira = new Colheitadeira();
  
  // Criando o comércio (à direita)
  commerce = createVector(width - 150, height / 2);
  
  // Criando uma linha reta de milho
  let startX = 100;  // Começo da linha de milho
  let step = 60;  // Distância entre os itens de milho
  for (let i = 0; i < 10; i++) {
    milhoItems.push(createVector(startX + i * step, height / 2));  // Posicionando os itens ao longo de uma linha
  }
}

function draw() {
  background(200);

  // Mostrar o comércio (um retângulo verde)
  fill(0, 255, 0);
  noStroke();
  rect(commerce.x, commerce.y, 100, 50);
  fill(0);
  textSize(16);
  text("Comércio", commerce.x + 15, commerce.y + 30);

  // Mostrar os itens de milho restantes (círculos amarelos)
  for (let i = 0; i < milhoItems.length; i++) {
    fill(255, 255, 0);  // Cor amarela para o milho
    ellipse(milhoItems[i].x, milhoItems[i].y, 20, 20);  // Representando milho com círculos amarelos
  }

  // Mostrar a colheitadeira
  colheitadeira.update();
  colheitadeira.display();

  // Verificar se a colheitadeira coletou algum item de milho
  for (let i = milhoItems.length - 1; i >= 0; i--) {
    if (dist(colheitadeira.position.x + 50, colheitadeira.position.y, milhoItems[i].x, milhoItems[i].y) < 25) {
      milhoItems.splice(i, 1);  // Remover item de milho do array
      coletados++;  // Aumenta o número de milhos coletados
    }
  }

  // Verificar se a colheitadeira chegou ao comércio
  if (dist(colheitadeira.position.x + 50, colheitadeira.position.y, commerce.x, commerce.y) < 40) {
    fill(0);
    textSize(32);
    text(`Milhos coletados: ${coletados}`, width / 2 - 150, height / 2);
    text("Chegou ao Comércio!", width / 2 - 150, height / 2 + 40);
  }
}

class Colheitadeira {
  constructor() {
    this.position = createVector(50, height / 2);  // Começa na esquerda da tela
    this.velocity = createVector(2, 0);  // Movimento contínuo para a direita
    this.size = 40;
    this.headWidth = 80;  // Largura da cabeça de colheita
    this.headHeight = 20; // Altura da cabeça de colheita
  }

  update() {
    // A colheitadeira se move sempre para a direita
    if (this.position.x < commerce.x - 40) {
      this.position.add(this.velocity);  // Atualiza a posição
    }
  }

  display() {
    // Corpo da colheitadeira (base)
    fill(255, 165, 0);
    noStroke();
    rect(this.position.x, this.position.y - 15, this.size, 30);  // Corpo

    // Cabeça de colheita (parte da frente da colheitadeira)
    fill(150, 75, 0);  // Cor mais escura para a cabeça de colheita
    rect(this.position.x - this.headWidth / 2, this.position.y - this.headHeight / 2, this.headWidth, this.headHeight);  // Cabeça de colheita

    // Rodas da colheitadeira
    fill(0);
    ellipse(this.position.x + 5, this.position.y + 10, 15, 15);  // Roda esquerda
    ellipse(this.position.x + this.size - 5, this.position.y + 10, 15, 15);  // Roda direita
  }
}
